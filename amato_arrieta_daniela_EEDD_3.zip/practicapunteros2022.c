#include "linkedlist.h"
#define MAXSTR 20
#define MAX_STRING_LENGTH 70

typedef struct {
	char name[MAX_STRING_LENGTH];
	int current_capacity;
	LinkedList students;
}Classroom;

typedef struct {
	char name[MAX_STRING_LENGTH];
	int num_classrooms;
	Classroom *classrooms;
}Degree;

typedef struct {
	int num_degrees;
	Degree *elements;
}Degrees;

int llenaMemo (Degrees *degrees) {
	int ok, i = 0, j = 0, k = 0;
	FILE *g;
	char login_aux[MAX_STRING_LENGTH], filename2[MAX_STRING_LENGTH], basura, stud_nameaux[MAX_STRING_LENGTH], aux[MAX_STRING_LENGTH], aux2[MAX_STRING_LENGTH];
	Element student;

	do {
		printf ("\nType the name of the 'students' file: ");
		scanf ("%s", filename2);
		scanf ("%c", &basura);

		g = fopen (filename2, "r");

		if (g == NULL) {
			printf ("\nERROR: Can't open file '%s'\n", filename2);
		}
		else {
			fscanf (g, "%s", aux);
			while (!feof (g)) {
				i = 0;
				j = 0;
				while (aux[i] != ',') {
					stud_nameaux[j] = aux[i];
					i++;
					j++;
				}
				stud_nameaux[j] = '\0'; 
				fscanf (g, "%c", &basura);
				fgets (aux2, MAX_STRING_LENGTH, g);
				aux2[strlen (aux2) - 1] = '\0';
				fgets (login_aux, MAX_STRING_LENGTH, g);
				if (login_aux[strlen (login_aux) - 1] == '\n') {
					login_aux[strlen (login_aux) - 1] = '\0';
				}
				
				for (k = 0; k < degrees->num_degrees; k++) {
					if (strcmp (degrees->elements[k].name, aux2) == 0) {
						degrees->elements[k].classrooms[0].current_capacity++;
						strcpy (student.name, stud_nameaux);
						strcpy (student.login, login_aux);
						LINKEDLIST_add(degrees->elements[k].classrooms[0].students, student);
					}
				}
				fscanf (g, "%s", aux);
			}
			
			ok = 1;
			fclose(g);
		}
	}while (g == NULL);

	return ok;
}

int pideMemo (Degrees *degrees) {
	char filename1[MAXSTR], basura;
	int ok, i, j;
	FILE *f;

	do {
		printf ("Type the name of the 'classrooms' file: ");
		scanf ("%s", filename1);
		scanf ("%c", &basura);

		f = fopen (filename1, "r");

		if (f == NULL) {
			printf ("\nERROR: Can't open file '%s'\n\n", filename1);
		}
		else {
			fscanf (f, "%d", &degrees->num_degrees);
			fscanf (f, "%c", &basura);
			degrees->elements = (Degree *) malloc (sizeof (Degree) * degrees->num_degrees);
			if (degrees->elements == NULL) {
				printf ("Error\n");
			}
			else {
				for (i = 0; i < degrees->num_degrees; i++) {
					fscanf (f, "%d", &degrees->elements[i].num_classrooms);
					fscanf (f, "%c", &basura);
					fgets (degrees->elements[i].name, MAX_STRING_LENGTH, f);
					degrees->elements[i].name[strlen (degrees->elements[i].name) - 1] = '\0';
					degrees->elements[i].classrooms = (Classroom *) malloc (sizeof (Classroom) * degrees->elements[i].num_classrooms);

					if (degrees->elements[i].classrooms == NULL) {
						printf ("Error\n");
					}
					else {

						for (j = 0; j < degrees->elements[i].num_classrooms; j++) {
							fscanf (f, "%s", degrees->elements[i].classrooms[j].name);
							fscanf (f, "%c", &basura);
							degrees->elements[i].classrooms[j].current_capacity = 0;
							degrees->elements[i].classrooms[j].students = LINKEDLIST_create();
						}
					}
				}
			}
			fclose (f);
		}
	} while (f == NULL);

	ok = llenaMemo (degrees);	
	
	return ok;
}

int displayMenu () {
	int opcion;
	char basura;

	do {
		printf ("\n1. Summary | 2. Show degree students | 3. Move student | 4. Exit\n");
		printf ("Select option: ");
		scanf ("%d", &opcion);
		scanf ("%c", &basura);

		if (opcion < 1 || opcion > 4) {
			printf ("\nERROR: Wrong option number\n");
		}
	} while (opcion < 1 || opcion > 4);

	return opcion;
}

void showSummary (Degrees *degrees) {
	int i, j;

	for (i = 0; i < degrees->num_degrees; i++) {
		printf ("\n%s\n", degrees->elements[i].name);
		for (j = 0; j < degrees->elements[i].num_classrooms; j++) {
			printf ("%s %d/inf\n", degrees->elements[i].classrooms[j].name, degrees->elements[i].classrooms[j].current_capacity);
		}
	}
}

void showStudent (Degrees *degrees) {
	int i, j, flag = 0;
	char degree[MAX_STRING_LENGTH];
	Element student;

	printf ("\nDegree to show? ");
	fgets (degree, MAX_STRING_LENGTH, stdin);
	degree[strlen (degree) - 1] = '\0';
	printf ("\n");

	for (i = 0; i < degrees->num_degrees; i++) {
		if (strcmp (degrees->elements[i].name, degree) == 0) {
			flag = 1;
			for (j = 0; j < degrees->elements[i].num_classrooms; j++) {
				LINKEDLIST_goToHead(degrees->elements[i].classrooms[j].students);
				while (!LINKEDLIST_isAtEnd(degrees->elements[i].classrooms[j].students)) {
					student = LINKEDLIST_get(degrees->elements[i].classrooms[j].students);
					printf ("%s (%s): %s\n", student.name, student.login, degrees->elements[i].classrooms[j].name);
					LINKEDLIST_next(degrees->elements[i].classrooms[j].students);
				}
			}
		}
	}

	if (flag == 0) {
		printf ("ERROR: Can't find degree\n");
	}
}

void moveStudent (Degrees *degrees) {
	int i, j, k = 1, class, flag = 0, flag2 = 1;
	char degree[MAX_STRING_LENGTH], student[MAX_STRING_LENGTH];
	char basura;
	Element stud;

	printf ("\nDegree? ");
	fgets (degree, MAX_STRING_LENGTH, stdin);
	degree[strlen (degree) - 1] = '\0';

	for (i = 0; i < degrees->num_degrees; i++) {
		if (strcmp (degrees->elements[i].name, degree) == 0) {
			flag = 1;
			printf ("\nClassrooms and capacity:\n");
			for (j = 0; j < degrees->elements[i].num_classrooms; j++) {
				printf ("%d. %s %d/inf\n", k, degrees->elements[i].classrooms[j].name, degrees->elements[i].classrooms[j].current_capacity);
				LINKEDLIST_goToHead(degrees->elements[i].classrooms[j].students);
				while (!LINKEDLIST_isAtEnd(degrees->elements[i].classrooms[j].students)) {
					stud = LINKEDLIST_get(degrees->elements[i].classrooms[j].students);
					printf ("%s\n", stud.login);
					LINKEDLIST_next(degrees->elements[i].classrooms[j].students);
				}

				k++;
			}
			flag2 = 0;
			printf ("\nWho do you want to move (login)? ");
			fgets (student, MAX_STRING_LENGTH, stdin);
			student[strlen (student) - 1] = '\0';

			for (j = 0; j < degrees->elements[i].num_classrooms; j++) {
				LINKEDLIST_goToHead(degrees->elements[i].classrooms[j].students);
				while (!LINKEDLIST_isAtEnd(degrees->elements[i].classrooms[j].students)) {
					stud = LINKEDLIST_get(degrees->elements[i].classrooms[j].students);
					if (strcmp (stud.login, student) == 0 && flag2 == 0) {
						flag2 = 1;
						printf ("\nTo which classroom (index)? ");
						scanf ("%d", &class);
						scanf ("%c", &basura);
						
						if (class > degrees->elements[i].num_classrooms || class == 0 || class < 0) {
							printf ("\nERROR: Can't move student\n");		
						}
						else {
							if (j + 1 == class) {
								printf ("\nERROR: Can't move student\n");		
							}
							else {
								class--;
								LINKEDLIST_add(degrees->elements[i].classrooms[class].students, stud);
								LINKEDLIST_remove(degrees->elements[i].classrooms[j].students);
								degrees->elements[i].classrooms[class].current_capacity++;
								degrees->elements[i].classrooms[j].current_capacity--;
							}
						}
					}
					LINKEDLIST_next(degrees->elements[i].classrooms[j].students);
				}
			}
		}
		}
	

	if (flag == 0) {
		printf ("\nERROR: Can't move student\n");
	}

	if (flag2 == 0) {
		printf ("\nERROR: Can't move student\n");
	}
}


void freeMemo (Degrees *degrees) {
	int i, j;

	for (i = 0; i < degrees->num_degrees; i++) {
		for (j = 0; j < degrees->elements[i].num_classrooms; j++) {
			LINKEDLIST_destroy(&degrees->elements[i].classrooms[j].students);
		}
		free (degrees->elements[i].classrooms);
	}

	free (degrees->elements);
}

int main () {
	Degrees degrees;
	int ok, opcion;

	printf ("Welcome!\n\n");

	ok = pideMemo (&degrees);

	if (ok == 1) {
		do {
			opcion = displayMenu ();

			if (opcion == 1) {
				showSummary (&degrees);
			}

			if (opcion == 2) {
				showStudent (&degrees);
			}

			if (opcion == 3) {
				moveStudent (&degrees);
			}
		} while (opcion != 4);
	}

	if (opcion == 4) {
		freeMemo (&degrees);
		printf ("\nBye!\n");
	}

	return 0;
}

